//============================================================================
// Name        : Project2AO.cpp
// Author      : Andrew Obrochta
// Version     : 1.0
// Copyright   : Snhu 2023
//============================================================================

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>

using namespace std;

struct Course {
    string courseCode;
    string courseName;

    vector<string> prerequisites;

    Course() {};
    Course(string code, string name) {
        courseCode = code;
        courseName = name;
    }
    Course(string code, string name, vector<string> prereqs) {
        courseCode = code;
        courseName = name;
        vector<string> prerequisites = prereqs;
    }
};

struct Node {
    Course course;
    Node* left;
    Node* right;

    Node() {
        left = nullptr;
        right = nullptr;
    }

    Node(Course acourse) : Node() {
        this->course = acourse;
    }
};

class CoursePlanner {
private:
    Node* root;
    void addNode(Course acourse, Node* node);
    void inOrder(Node* node);
    void printCourse(Node* node, string courseCode);

public:
    CoursePlanner();
    void InOrder();
    void PrintCourse(string courseCode);
    bool loadData();
    bool validatePrerequisites(Course course);
    void insert(Course course);
};

CoursePlanner::CoursePlanner() {
    root = nullptr;
}

void CoursePlanner::InOrder() {
    this->inOrder(root);
}

void CoursePlanner::PrintCourse(string courseCode) {
    this->printCourse(root, courseCode);
}

void CoursePlanner::insert(Course course) {
    if (root == nullptr) {
        root = new Node(course);
    }
    else {
        this->addNode(course, root);
    }
}

void CoursePlanner::addNode(Course acourse, Node* node) {
    if (node->course.courseCode.compare(acourse.courseCode) > 0) {
        if (node->left == nullptr) {
            node->left = new Node(acourse);
        }
        else {
            this->addNode(acourse, node->left);
        }
    }
    else {
        if (node->right == nullptr) {
            node->right = new Node(acourse);
        }
        else {
            this->addNode(acourse, node->right);
        }
    }
}

void CoursePlanner::inOrder(Node* node) {
    if (node != nullptr) {
        inOrder(node->left);
        cout << "Course Code: " << node->course.courseCode;
        cout << " Course Name: " << node->course.courseName;
        cout << " Prerequisite(s): ";
        for (int i = 0; i < node->course.prerequisites.size(); ++i) {
            cout << node->course.prerequisites[i] << " ";
        }
        if (node->course.prerequisites.size() == 0) {
            cout << "None";
        }
        cout << "\n";
        inOrder(node->right);
    }
    return;
}

void CoursePlanner::printCourse(Node* node, string courseCode) {
    while (node != nullptr) {
        if (node->course.courseCode.compare(courseCode) == 0) {
            cout << "Course Code: " << node->course.courseCode;
            cout << "  Course Name: " << node->course.courseName;
            cout << "  Prerequisite(s): ";
            for (int i = 0; i < node->course.prerequisites.size(); ++i) {
                cout << node->course.prerequisites[i] << " ";
            }
            if (node->course.prerequisites.size() == 0) {
                cout << "None";
            }
            cout << "\n";
            return;
        }
        else if (node->course.courseCode.compare(courseCode) > 0 && node->left != nullptr) {
            node = node->left;
        }
        else if (node->course.courseCode.compare(courseCode) < 0 && node->right != nullptr) {
            node = node->right;
        }
        else {
            cout << "Course cannot be found.\n";
            return;
        }
    }
    if (root == nullptr) {
        cout << "Cannot load data. =[ \n";
        return;
    }
}

bool CoursePlanner::loadData() {
    ifstream file;
    file.open("courseinfo.txt");

    if (file.is_open()) {
        while (!file.eof()) {
            vector<string> courseLine;
            string line;

            getline(file, line);
            while (line.length() > 0) {
                unsigned int delim = line.find(',');
                if (delim < 100) {
                    courseLine.push_back(line.substr(0, delim));
                    line.erase(0, delim + 1);
                }
                else {
                    courseLine.push_back(line.substr(0, line.length()));
                    line = "";
                }
            }

            Course course;

            course.courseCode = courseLine[0];
            course.courseName = courseLine[1];
            for (unsigned int i = 2; i < courseLine.size(); i++) {
                course.prerequisites.push_back(courseLine[i]);
            }
            insert(course);
        }
        return true;
    }
    if (!file) {
        cout << "The file is invalid\n";
        return false;
    }
    file.close();
}

bool CoursePlanner::validatePrerequisites(Course course) {
    Node* current = root;
    if (current->course.prerequisites.size() > 0) {
        for (int i = 0; i < course.prerequisites.size(); i++) {
            while (current != nullptr) {
                if (course.prerequisites[i] == current->course.courseCode) {
                    return true;
                }
                else if (course.prerequisites[i].compare(current->course.courseCode) > 0 && current->left != nullptr) {
                    current = current->left;
                }
                else if (course.prerequisites[i].compare(current->course.courseCode) < 0 && current->right != nullptr) {
                    current = current->right;
                }
                else {
                    cout << "Prerequisite not found. \n";
                    return false;
                }
            }
        }
    }
    else {
        return true;
    }
}

int main()
{
    CoursePlanner* planner = new CoursePlanner();
    string courseCode;
    int choice = 0;

    cout << "Welcome to the Course Planner Menu! \n\n";
    while (choice != 4) {
        cout << "           MENU           \n";
        cout << "[1] Load Course Data      \n";
        cout << "[2] Print Course List        \n";
        cout << "[3] Print Course             \n";
        cout << "[4] Exit                     \n";
        cout << "What would you like to do? ";
        cin >> choice;

        switch (choice) {
        case 1:
            planner->loadData();
            break;
        case 2:
            cout << "\nHere is a sample schedule: \n";
            cout << "---------------------------- \n";
            planner->InOrder();
            cout << "\n";
            break;
        case 3:
            cout << "Enter the course code you would like to search: ";
            cin >> courseCode;
            planner->PrintCourse(courseCode);
            cout << "\n";
            break;
        case 4:
            cout << "\nThanks for using!\n";
            break;
        default:
            cout << choice << " is not a option that prompted. Please enter a number 1 - 4.\n";
        }
    }
    return 0;
}
